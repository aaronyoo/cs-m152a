# Lab 0

There are 3 deliverables needed in Lab 0
1. Simulation and Implementation of of combinatorial gates example
2. Simulation of two 4-bit counters
3. Implementation of LED with Flashing 1-HZ frequency

The different parts are organized into different folders.
